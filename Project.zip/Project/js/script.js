$(document).ready(function () {
    $('.password-control').on('click', function () {
        let $input = $(this).parent().find('input').first();
        if ($input.attr('type') === 'password') {
            $input.attr('type', 'text');
            $(this).addClass('view');
        } else {
            $input.attr('type', 'password');
            $(this).removeClass('view');
        }
        return false;
    });

    $('#inputPassword1, #inputPassword2').on('change', function () {
        let pass1 = $('#inputPassword1');
        let pass2 = $('#inputPassword2');
        if (pass1.val() !== pass2.val())
            pass2[0].setCustomValidity("Passwords Don't Match");
        else
            pass2[0].setCustomValidity('');
    });
    window.onload = function () {
        document.getElementById("inputPassword1").onchange = validatePassword;
        document.getElementById("inputPassword2").onchange = validatePassword;
    }

    function validatePassword() {
        let pass2 = document.getElementById("inputPassword2").value;
        let pass1 = document.getElementById("inputPassword1").value;
        if (pass1 !== pass2)
            document.getElementById("inputPassword2").setCustomValidity("Passwords Don't Match");
        else
            document.getElementById("inputPassword2").setCustomValidity('');
    }
});